#-*- coding:utf-8 -*-
#!/usr/bin/env python
'''
    @File    :   cosine.py
    @Time    :   2023/10/17 09:31:40
    @Author  :   12718 
    @Version :   1.0
'''
import math
from torch.optim import Optimizer
from .scheduler import LRScheduler

class CosineLRScheduler(LRScheduler):
    def __init__(self, optimizer: Optimizer, max_step:int, lr_min:float=1e-6, warmup_step:int=0, start:int=-1):
        super().__init__(optimizer, start)
        self.warmup_step = warmup_step
        self.max_step = max_step
        self.lr_min = lr_min
        print("Initial learning rate set to:{}".format([group["initial_lr"] for group
                                                        in self.optimizer.param_groups]))
    
    def get_lr(self):
        def calc_lr(group):
            if self.current_step < self.warmup_step:
                lr = group["initial_lr"] * self.current_step / self.warmup_step
            else:
                lr = self.lr_min + (group["initial_lr"] - self.lr_min) * 0.5 * \
            (1. + math.cos(math.pi * (self.current_step - self.warmup_step) / (self.max_step - self.warmup_step)))
            return lr
        return [calc_lr(group) for group in self.optimizer.param_groups]

    def state_dict(self):
        return {
            key:value
            for key, value in self.__dict__.items()
            if key in ["max_step", "lr_min", "current_step",
                       "warmup_step"]
        }

    def load_state_dict(self, state_dict):
        tmp_state = {}
        keys = ["max_step", "lr_min", "current_step", "warmup_step"]
        for key in keys:
            if key not in state_dict:
                raise KeyError(
                    "key '{}'' is not specified in "
                    "state_dict when loading state dict".format(key)
                )
            tmp_state[key] = state_dict[key]
        self.__dict__.update(tmp_state)
        