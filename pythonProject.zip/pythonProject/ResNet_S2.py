import pandas as pd
import torch
from torch.utils.data import DataLoader, TensorDataset, random_split
import torch.optim as optim
import torch.nn as nn
import torch.nn.functional as F
from sklearn.metrics import roc_curve, auc
from sklearn.preprocessing import label_binarize
import numpy as np
import matplotlib.pyplot as plt
import random
from sklearn.metrics import precision_score, recall_score, f1_score, accuracy_score

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(device)

# 设置随机种子以确保可重复性
def set_random_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

seed = 14 #accuracy 53.6% Precision 0.68 recall 0.52
set_random_seed(seed)

# 读取csv文档数据，跳过第一行
def load_data_from_csv(file_path):
    data = pd.read_csv(file_path, skiprows=0)
    X = data.iloc[:, :-1].values
    y = data.iloc[:, -1].values
    # 确保标签从0开始连续编号
    y -= np.min(y)  # 使标签从0开始
    return X, y

# 假设txt文件路径为'S1.csv'
file_path = 'D:\AI学习\Tcodes\pythonProject\input\S2_Pannel_No5.csv'
X, y = load_data_from_csv(file_path)

# 数据标准化或归一化
#from sklearn.preprocessing import StandardScaler
#scaler = StandardScaler()
#X_scaled = scaler.fit_transform(X)

# 假设 X 和 y 已经被加载为 NumPy 数组
# 首先，将它们转换为 PyTorch 张量
X = torch.tensor(X, dtype=torch.float32)  # 将特征数据转换为 float32 类型
y = torch.tensor(y, dtype=torch.long)  # 转换标签数据为 long 类型，并移除单一维度

# 调整 X 的维度以匹配 Conv1d: [batch_size, channels, length]
X = X.view(X.shape[0], 1, 14)

# 创建数据集和数据加载器
dataset = TensorDataset(X, y)
train_size = int(0.9 * len(dataset))
test_size = len(dataset) - train_size
train_dataset, test_dataset = random_split(dataset, [train_size, test_size])

train_loader = DataLoader(train_dataset, batch_size=64, shuffle=True)
test_loader = DataLoader(test_dataset, batch_size=64, shuffle=False)

class Simple1DCNN(nn.Module):
    def __init__(self, num_features, num_classes):
        super(Simple1DCNN, self).__init__()
        self.conv1 = nn.Conv1d(in_channels=1, out_channels=16, kernel_size=3, padding=1)
        self.pool = nn.MaxPool1d(2)
        self.conv2 = nn.Conv1d(16, 32, kernel_size=3, padding=1)
        self.fc = nn.Linear(32 * (num_features // 4), num_classes)  # 根据池化和输入尺寸调整

    def forward(self, x):
        x = self.pool(F.relu(self.conv1(x)))
        x = self.pool(F.relu(self.conv2(x)))
        x = torch.flatten(x, 1)  # 展平张量以进行全连接
        x = self.fc(x)
        return x

class EnhancedCNN(nn.Module):
    def __init__(self, num_features, num_classes):
        super(EnhancedCNN, self).__init__()
        self.layer1 = nn.Sequential(
            nn.Conv1d(in_channels=1, out_channels=16, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.MaxPool1d(2)
        )
        self.layer2 = nn.Sequential(
            nn.Conv1d(16, 32, kernel_size=3, padding=1),
            nn.ReLU()
        )
        self.layer3 = nn.Sequential(
            nn.Conv1d(32, 64, kernel_size=3, padding=1),
            nn.ReLU()
        )
        self.layer4 = nn.Sequential(
            nn.Conv1d(64, 128, kernel_size=3, padding=1),
            nn.ReLU()
        )
        self.layer5 = nn.Sequential(
            nn.Conv1d(128, 256, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.MaxPool1d(2)
        )
        # 计算全连接层的输入尺寸
        final_size = num_features // 4  # 适当调整此值以匹配数据维度
        self.fc = nn.Linear(256 * final_size, num_classes)

    def forward(self, x):
        x = self.layer1(x)
        x = self.layer2(x)
        x = self.layer3(x)
        x = self.layer4(x)
        x = self.layer5(x)
        x = torch.flatten(x, 1)
        x = self.fc(x)
        return x

model = EnhancedCNN(num_features=14, num_classes=3).to(device)

criterion = nn.CrossEntropyLoss()
optimizer = optim.RMSprop(model.parameters(), lr=0.01, alpha=0.7)

# 初始化损失记录器
epoch_losses = []

# 训练模型
model.train()
for epoch in range(80):  # RMSprop需要训练80个epoch
    total_loss = 0
    correct = 0
    count = 0
    total_samples = 0
    for data, targets in train_loader:
        data, targets = data.to(device), targets.to(device)
        optimizer.zero_grad()
        outputs = model(data)
        loss = criterion(outputs, targets)
        loss.backward()
        optimizer.step()
        total_loss += loss.item()
        count += 1

        # 计算训练准确度
        _, predicted = torch.max(outputs.data, 1)
        total_samples += targets.size(0)
        accuracy = correct / total_samples * 100
        correct += (predicted == targets).sum().item()

    average_loss = total_loss / count
    epoch_losses.append(average_loss)
    print(f'Epoch {epoch+1}, Loss: {average_loss}, Accuracy: {accuracy}%')


# 二值化标签
num_classes = 3 # 根据你的类别数量修改
y_true = []
y_scores = []

# 评估模型
model.eval()
correct = 0
total = 0
with torch.no_grad():
    for data, targets in test_loader:
        data, targets = data.to(device), targets.to(device)
        outputs = model(data)
        _, predicted = torch.max(outputs.data, 1)
        total += targets.size(0)
        correct += (predicted == targets).sum().item()

        probabilities = F.softmax(outputs, dim=1)  # 计算概率

        y_true.extend(targets.cpu().numpy())
        y_scores.extend(probabilities.cpu().numpy())

print(f'Test Accuracy: {100 * correct / total}%')

y_scores = np.array(y_scores)

# 预测类别（从概率到类别标签）
y_pred = np.argmax(y_scores, axis=1)

#for i in range(test_size):
#    print(f'ture {y_true[i]}', f'pred {y_pred[i]}', f'{y_scores[i]}')

# 处理标签和分数以用于ROC计算
y_true = label_binarize(y_true, classes=[i for i in range(num_classes)])

# 计算精确度和召回率
precision = precision_score(y_true.argmax(axis=1), y_pred, average='macro', zero_division=0)
recall = recall_score(y_true.argmax(axis=1), y_pred, average='macro')
f1 = f1_score(y_true.argmax(axis=1), y_pred, average='macro')


print(f'Precision: {precision:.4f}')
print(f'Recall: {recall:.4f}')
print(f'F1 Score: {f1:.4f}')

# 计算每个类的ROC AUC
fpr = dict()
tpr = dict()
roc_auc = dict()
for i in range(num_classes):
    fpr[i], tpr[i], _ = roc_curve(y_true[:, i], y_scores[:, i])
    roc_auc[i] = auc(fpr[i], tpr[i])

# 绘制ROC曲线
plt.figure()
lw = 2  # 线宽
colors = ['blue', 'red', 'green', 'purple']
for i in range(num_classes):
    plt.plot(fpr[i], tpr[i], color=colors[i], lw=lw,
             label='class {0} (AUC = {1:0.2f})'.format(i+5, roc_auc[i]))

plt.plot([0, 1], [0, 1], 'k--', lw=lw)
plt.xlim([0.0, 1.0])
plt.ylim([0.0, 1.05])
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('ROC for Multi-Class using CNN')
plt.legend(loc="lower right")
plt.show()

# 在绘制ROC曲线后再绘制损失曲线
plt.plot(epoch_losses)
plt.title('Training Loss Over Epochs using ResNet')
plt.xlabel('Epochs')
plt.ylabel('Loss')
plt.grid(True)
plt.show()