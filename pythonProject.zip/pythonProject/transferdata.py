import pandas as pd
import numpy as np

# 读取用户上传的csv文件
file_path = 'D:\AI学习\Tcodes\pythonProject\input\S1_Pannel.csv'
data = pd.read_csv(file_path, skiprows=0)
X = data.iloc[:, :-1].values
y = data.iloc[:, -1].values
# 确保标签从0开始连续编号
y -= np.min(y)  # 使标签从0开始

X_text = []

# 假设我们需要处理文本数据，这里简单地将所有数值数据转换为字符串
for i in range(len(y)):
    text = '第0种自行车出行时间' + str(X[i,1]) + '分钟，出行费用' +str(X[i,2])+ '元，第1种出行方式公交总出行时间'+str(X[i,6])+'分钟,其中公交步行时间'+str(X[i,3])+'分钟，公交等待时间'+str(X[i,4])+'分钟，公交车内时间'+str(X[i,5])+'分钟,出行费用'+str(X[i,7])+'元,第2种小汽车出行总时间'+str(X[i,8])+'分钟,总出行费用'+str(X[i,9])+'元，第3种出行方式自行车换乘公交总出行时间'+str(X[i,10])+'分钟，其中自行车骑车时间'+str(X[i,11])+'分钟，换乘步行时间'+str(X[i,12])+'分钟，换乘等待时间'+str(X[i,13])+'分钟，公交车内时间'+str(X[i,14])+'分钟，出行总费用'+str(X[i,15])+'元，编号'+str(X[i,0])+'的出行者会选择哪种出行方式？'
    X_text.append(text)

df = pd.DataFrame({'text': X_text, 'label': y})

print(df)

# 保存处理后的数据到新的csv文件
processed_file_path = 'D:\AI学习\Tcodes\pythonProject\input\S1_processed_texts.csv'
df.to_csv(processed_file_path, index=False, encoding='utf-8-sig')


