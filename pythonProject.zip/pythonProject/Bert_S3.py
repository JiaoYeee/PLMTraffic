import pandas as pd
import torch
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset, random_split
from tqdm import tqdm
import os
from transformers import AutoTokenizer, BertConfig, BertForSequenceClassification
import matplotlib.pyplot as plt
from sklearn.metrics import roc_curve, auc, precision_score, recall_score, f1_score
from sklearn.preprocessing import label_binarize
import random
import numpy as np

def set_random_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

seed = 2
set_random_seed(seed)

# 设置环境变量以禁用 Flash Attention
os.environ["TORCH_CUDA_SDP"] = "0"

# 读取CSV文件
data = pd.read_csv('D:\AI学习\Tcodes\pythonProject\input\S3_processed_texts.csv')
texts = data['text'].tolist()  # 确保 texts 是一个字符串列表
labels = data['label'].values  # 保持 labels 为一个 numpy 数组

# 初始化BERT模型和tokenizer
model_name = "google-bert/bert-base-chinese"
tokenizer = AutoTokenizer.from_pretrained(model_name)

# 加载预训练的BERT模型
#model = AutoModelForSequenceClassification.from_pretrained(model_name, num_labels=len(set(labels)))
# 使用 BertForSequenceClassification 以便能够添加 Dropout 层
config = BertConfig.from_pretrained(model_name, hidden_dropout_prob=0.3)
model = BertForSequenceClassification.from_pretrained(model_name, num_labels=len(set(labels)))

# 数据编码
encoded_inputs = tokenizer(texts, padding="max_length", truncation=True, max_length=300, return_tensors="pt")
input_ids = encoded_inputs['input_ids']
attention_mask = encoded_inputs['attention_mask']

# 创建数据集
dataset = TensorDataset(input_ids, attention_mask, torch.tensor(labels))

# 划分训练集和测试集
train_size = int(0.9 * len(dataset))
test_size = len(dataset) - train_size
train_dataset, test_dataset = random_split(dataset, [train_size, test_size])

# 创建数据加载器
train_loader = DataLoader(train_dataset, batch_size=4, shuffle=True)
test_loader = DataLoader(test_dataset, batch_size=4, shuffle=False)

# 将模型和数据移到 GPU 上
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(device)
model.to(device)

# 优化器
#optimizer = optim.RMSprop(model.parameters(), lr=0.00001, alpha=0.1)
optimizer = optim.AdamW(model.parameters(), lr=0.00001, weight_decay=0.3)
#scheduler = optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode='min', factor=0.1, patience=3)

# Cosine Annealing Scheduler
scheduler = optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=18)

# 训练模型并记录损失
num_epochs = 18
train_losses = []
val_losses = []
#best_val_loss = float('inf')
#patience = 3
#early_stop_counter = 0

model.train()
for epoch in range(num_epochs):
    total_loss = 0
    num_batches = 0

    for batch in tqdm(train_loader, desc=f"Epoch {epoch + 1}"):
        batch_inputs, batch_masks, batch_labels = [b.to(device) for b in batch]
        optimizer.zero_grad()
        outputs = model(input_ids=batch_inputs, attention_mask=batch_masks, labels=batch_labels)
        loss = outputs.loss
        loss.backward()
        optimizer.step()

        total_loss += loss.item()
        num_batches += 1


    avg_loss = total_loss / num_batches
    train_losses.append(avg_loss)
    print(f"Average Loss for Epoch {epoch + 1}: {avg_loss:.4f}")

    # Step the scheduler
    scheduler.step()

    # 清除缓存
    torch.cuda.empty_cache()

# 评估模型并记录损失和预测值
model.eval()
total_eval_accuracy = 0
total_eval_loss = 0
num_batches = 0
all_labels = []
all_preds = []
all_probs = []

with torch.no_grad():
    for batch in tqdm(test_loader, desc="Evaluating"):
        batch_inputs, batch_masks, batch_labels = [b.to(device) for b in batch]
        outputs = model(input_ids=batch_inputs, attention_mask=batch_masks, labels=batch_labels)
        loss = outputs.loss
        total_eval_loss += loss.item()

        preds = torch.argmax(outputs.logits, dim=1).flatten()
        probs = torch.softmax(outputs.logits, dim=1).cpu().numpy()
        all_labels.extend(batch_labels.cpu().numpy())
        all_preds.extend(preds.cpu().numpy())
        all_probs.extend(probs)  # 确保all_probs是二维数组

        accuracy = (preds == batch_labels).cpu().numpy().mean() * 100
        total_eval_accuracy += accuracy
        num_batches += 1

        avg_val_accuracy = total_eval_accuracy / num_batches
        avg_val_loss = total_eval_loss / num_batches
        val_losses.append(avg_val_loss)

    # 计算precision和recall
    precision = precision_score(all_labels, all_preds, average='macro', zero_division=0)
    recall = recall_score(all_labels, all_preds, average='macro')
    f1 = f1_score(all_labels, all_preds, average='macro')

print(f"Validation Loss: {avg_val_loss:.4f}")
print(f"Validation Accuracy: {avg_val_accuracy:.2f}%")
print(f"Precision: {precision:.4f}")
print(f"Recall: {recall:.4f}")
print(f'F1 Score: {f1:.4f}')

# 确保all_probs是numpy二维数组
all_probs = np.array(all_probs)

# 绘制ROC曲线
all_labels_binarized = label_binarize(all_labels, classes=list(range(len(set(labels)))))
fpr = dict()
tpr = dict()
roc_auc = dict()

for i in range(len(set(labels))):
    fpr[i], tpr[i], _ = roc_curve(all_labels_binarized[:, i], np.array(all_probs)[:, i])
    roc_auc[i] = auc(fpr[i], tpr[i])

colors = ['purple', 'cyan', 'orange']
for i in range(len(set(labels))):
    plt.plot(fpr[i], tpr[i], color=colors[i], label=f'Class {i+8} (AUC = {roc_auc[i]:.2f})')

plt.plot([0, 1], [0, 1], 'k--')
plt.xlim([0.0, 1.0])
plt.ylim([0.0, 1.05])
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('ROC for Multi-Class using PLM')
plt.legend(loc="lower right")
plt.show()

# 绘制损失曲线
plt.plot(range(1, num_epochs + 1), train_losses, label='Train Loss')
#plt.plot(range(1, num_epochs + 1), val_losses, label='Validation Loss')
plt.xlabel('Epochs')
plt.ylabel('Loss')
plt.title('Training Loss')
plt.legend()
plt.show()

