from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.metrics import roc_curve, auc, precision_score, recall_score, f1_score
from sklearn.preprocessing import label_binarize
from sklearn.metrics import log_loss
from sklearn.metrics import accuracy_score
import numpy as np
import random
import torch

def set_random_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

seed = 2
set_random_seed(seed)

# 读取CSV文件
data = pd.read_csv('D:\AI学习\Tcodes\pythonProject\input\S3_Pannel.csv')

# 分离特征和标签
X = data.drop(columns=['CHOICE'])
y = data['CHOICE']
y -= np.min(y)  # 使标签从0开始

# 拆分数据集
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.1, random_state=42)

# Initialize lists to store losses
train_losses = []
test_losses = []

# 初始化随机森林分类器
model = RandomForestClassifier(n_estimators=100, random_state=42)

# Number of epochs for manual training
num_epochs = 50

# Train the model manually to record losses
for epoch in range(num_epochs):
    model.fit(X_train, y_train)

    # Calculate train and test loss
    train_loss = log_loss(y_train, model.predict_proba(X_train))
    test_loss = log_loss(y_test, model.predict_proba(X_test))

    # Append losses to the lists
    train_losses.append(train_loss)
    test_losses.append(test_loss)


# Compute ROC curve and ROC area for each class
y_test_binarized = label_binarize(y_test, classes=[0, 1, 2])
n_classes = y_test_binarized.shape[1]

y_score = model.predict_proba(X_test)
y_pred = model.predict(X_test)

# 评估模型
accuracy = accuracy_score(y_test, y_pred)
precision = precision_score(y_test, y_pred, average='macro')
recall = recall_score(y_test, y_pred, average='macro')
f1 = f1_score(y_test, y_pred, average='macro')

print(f'Accuracy: {accuracy:.4f}')
print(f'Precision: {precision:.4f}')
print(f'Recall: {recall:.4f}')
print(f'F1 Score: {f1:.4f}')

# Compute ROC curve and ROC area for each class
fpr = dict()
tpr = dict()
roc_auc = dict()
for i in range(n_classes):
    fpr[i], tpr[i], _ = roc_curve(y_test_binarized[:, i], y_score[:, i])
    roc_auc[i] = auc(fpr[i], tpr[i])

# Plotting ROC curves
colors = ['purple', 'cyan', 'orange']
for i, color in zip(range(n_classes), colors):
    plt.plot(fpr[i], tpr[i], color=color, lw=2,
             label='Class {0} (AUC = {1:0.2f})'.format(i+8, roc_auc[i]))
plt.plot([0, 1], [0, 1], 'k--', lw=2)
plt.xlim([0.0, 1.0])
plt.ylim([0.0, 1.05])
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('ROC for Multi-Class using RF')
plt.legend(loc="lower right")
plt.show()


