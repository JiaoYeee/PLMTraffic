import time
import torch

A = torch.ones(5000,5000).to('cuda')
B = torch.ones(5000,5000).to('cuda')
startTime2 = time.time()
for i in range(100):
    C = torch.matmul(A,B)
endTime2 = time.time()
print('gpu',round((endTime2-startTime2)*1000,2),'ms')

A = torch.ones(5000,5000)
B = torch.ones(5000,5000)
startTime2 = time.time()
for i in range(100):
    C = torch.matmul(A,B)
endTime2 = time.time()
print('cpu',round((endTime2-startTime2)*1000,2),'ms')