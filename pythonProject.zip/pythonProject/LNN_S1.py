import pandas as pd
import torch
from torch import nn
from torch.utils.data import DataLoader, TensorDataset, random_split
import numpy as np
import random
from sklearn.metrics import roc_curve, auc, precision_score, recall_score, f1_score
from sklearn.preprocessing import label_binarize
import matplotlib.pyplot as plt

# 设置随机种子以确保可重复性
def set_random_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

seed = 75 # accuracy 0.5
set_random_seed(seed)

# 读取csv文档数据，跳过第一行
def load_data_from_csv(file_path):
    data = pd.read_csv(file_path, skiprows=0)
    X = data.iloc[:, :-1].values
    y = data.iloc[:, -1].values
    y -= np.min(y)  # 使标签从0开始
    return X, y


# 假设txt文件路径为'data.txt'
file_path = 'D:\AI学习\Tcodes\pythonProject\input\S1_Pannel.csv'
X, y = load_data_from_csv(file_path)

# 检查标签值范围
print(f'Min label value: {y.min()}, Max label value: {y.max()}')

# 确保标签值在正确范围内
assert y.min() >= 0, "标签值小于0，请检查数据"
assert y.max() < 4, "标签值超出范围，请检查数据"

# 将数据转换为Tensor
X_tensor = torch.tensor(X, dtype=torch.float32)
y_tensor = torch.tensor(y, dtype=torch.long)

# 创建Dataset和DataLoader
dataset = TensorDataset(X_tensor, y_tensor)
train_size = int(0.8 * len(dataset))
test_size = len(dataset) - train_size
train_dataset, test_dataset = random_split(dataset, [train_size, test_size])

batch_size = 4
train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False)

# 模型定义
class SoftmaxRegression(nn.Module):
    def __init__(self, input_dim, num_classes):
        super(SoftmaxRegression, self).__init__()
        self.linear = nn.Linear(input_dim, num_classes)

    def forward(self, x):
        return self.linear(x)

# 定义模型
input_dim = X.shape[1]
num_classes = len(np.unique(y))
model = SoftmaxRegression(input_dim, num_classes)

# 训练和评估
import torch.optim as optim

criterion = nn.CrossEntropyLoss()

# 使用 Adam 优化器
initial_lr = 0.01
optimizer = optim.Adam(model.parameters(), lr=initial_lr)
scheduler = optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode='min', factor=0.1, patience=2)

def train(model, train_loader, criterion, optimizer, num_epochs):
    loss_values = []  # 用于存储每个epoch的损失值
    for epoch in range(num_epochs):
        model.train()
        total_loss = 0
        for X_batch, y_batch in train_loader:
            optimizer.zero_grad()
            outputs = model(X_batch)
            loss = criterion(outputs, y_batch)
            loss.backward()
            optimizer.step()
            total_loss += loss.item()
        avg_loss = total_loss / len(train_loader)
        loss_values.append(avg_loss)  # 记录平均损失值
        print(f'Epoch {epoch + 1}/{num_epochs}, Loss: {avg_loss:.4f}, Learning Rate: {scheduler.optimizer.param_groups[0]["lr"]:.6f}')

        # 调度器根据验证集的损失调整学习率
        scheduler.step(avg_loss)

    return loss_values

def evaluate_and_plot_roc(model, test_loader, num_classes):
    model.eval()
    all_preds = []
    all_targets = []
    with torch.no_grad():
        for X_batch, y_batch in test_loader:
            outputs = model(X_batch)
            probabilities = nn.functional.softmax(outputs, dim=1)
            all_preds.extend(probabilities.cpu().numpy())
            all_targets.extend(y_batch.cpu().numpy())

    # 将标签二值化
    all_targets = label_binarize(all_targets, classes=range(num_classes))

    # 计算每个类别的ROC AUC
    fpr = dict()
    tpr = dict()
    roc_auc = dict()
    for i in range(num_classes):
        fpr[i], tpr[i], _ = roc_curve(all_targets[:, i], np.array(all_preds)[:, i])
        roc_auc[i] = auc(fpr[i], tpr[i])

    # 绘制ROC曲线
    plt.figure()
    colors = ['teal', 'pink', 'brown', 'Navy']
    for i, color in enumerate(colors[:num_classes]):
        plt.plot(fpr[i], tpr[i], color=color, lw=2,
                 label='class {0} (AUC = {1:0.2f})'.format(i+1, roc_auc[i]))

    plt.plot([0, 1], [0, 1], 'k--', lw=2)
    plt.xlim([0.0, 1.0])
    plt.ylim([0.0, 1.05])
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.title('ROC for Multi-Class using LNN')
    plt.legend(loc="lower right")
    plt.show()

    # 计算并打印准确率、精确率、召回率和F1分数
    all_preds_classes = np.array(all_preds).argmax(axis=1)
    all_targets_classes = all_targets.argmax(axis=1)

    accuracy = (all_preds_classes == all_targets_classes).mean()
    precision = precision_score(all_targets_classes, all_preds_classes, average='macro')
    recall = recall_score(all_targets_classes, all_preds_classes, average='macro')
    f1 = f1_score(all_targets_classes, all_preds_classes, average='macro')

    print(f'Accuracy: {accuracy:.4f}')
    print(f'Precision: {precision:.4f}')
    print(f'Recall: {recall:.4f}')
    print(f'F1 Score: {f1:.4f}')


# 训练和评估
num_epochs = 50
loss_values = train(model, train_loader, criterion, optimizer, num_epochs)
evaluate_and_plot_roc(model, test_loader, num_classes)

# 绘制损失曲线

plt.plot(range(1, num_epochs + 1), loss_values)
plt.xlabel('Epoch')
plt.ylabel('Loss')
plt.title('Training Loss Over Epochs using LNN')
plt.grid(True)
plt.show()

